import { useCallback, useEffect, useRef, useState } from 'react';
import { photos } from './photos.js';

const categories = ['All work', ...new Set(photos.map((photo) => photo.category))];

function Arrow({ diagonal = false }) {
  return (
    <svg aria-hidden="true" viewBox="0 0 18 18" className="arrow-icon">
      {diagonal ? <path d="M4 14 14 4M5 4h9v9" /> : <path d="M2.5 9h12m-5-5 5 5-5 5" />}
    </svg>
  );
}

function PhotoCard({ photo, onOpen }) {
  return (
    <button className="photo-card" type="button" onClick={(event) => onOpen(photo, event)} aria-label={`Open photograph: ${photo.alt}`}>
      <img src={photo.src} alt={photo.alt} loading="lazy" decoding="async" />
      <span className="photo-card__caption">
        <span>{photo.title}</span>
        <span className="photo-card__category">{photo.category}</span>
      </span>
    </button>
  );
}

function Lightbox({ photo, onClose, onMove }) {
  const closeRef = useRef(null);
  useEffect(() => {
    closeRef.current?.focus();
    const handleKey = (event) => {
      if (event.key === 'Escape') onClose();
      if (event.key === 'ArrowRight') onMove(1);
      if (event.key === 'ArrowLeft') onMove(-1);
      if (event.key === 'Tab') {
        const controls = Array.from(document.querySelectorAll('.lightbox button'));
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', handleKey);
    document.body.classList.add('has-lightbox');
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.classList.remove('has-lightbox');
    };
  }, [onClose, onMove]);

  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label="Photograph viewer" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <button ref={closeRef} className="lightbox__close" onClick={onClose} aria-label="Close photograph">×</button>
      <button className="lightbox__previous" onClick={() => onMove(-1)} aria-label="Previous photograph">←</button>
      <figure className="lightbox__figure">
        <img src={photo.src} alt={photo.alt} />
        <figcaption>{photo.title}<span>{photo.category}</span></figcaption>
      </figure>
      <button className="lightbox__next" onClick={() => onMove(1)} aria-label="Next photograph">→</button>
    </div>
  );
}

export default function App() {
  const [category, setCategory] = useState('All work');
  const [activePhoto, setActivePhoto] = useState(null);
  const openerRef = useRef(null);
  const visiblePhotos = category === 'All work' ? photos : photos.filter((photo) => photo.category === category);
  const activeIndex = activePhoto ? visiblePhotos.findIndex((photo) => photo.src === activePhoto.src) : -1;

  const moveLightbox = useCallback((direction) => {
    if (visiblePhotos.length < 2) return;
    const next = (activeIndex + direction + visiblePhotos.length) % visiblePhotos.length;
    setActivePhoto(visiblePhotos[next]);
  }, [activeIndex, visiblePhotos]);

  const openPhoto = (photo, event) => {
    openerRef.current = event.currentTarget;
    setActivePhoto(photo);
  };
  const closeLightbox = () => {
    setActivePhoto(null);
    window.requestAnimationFrame(() => openerRef.current?.focus());
  };

  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Preston Zen, home">PRESTON <span>ZEN</span></a>
        <nav aria-label="Main navigation">
          <a href="#work">Selected work</a>
          <a href="#about">About</a>
          <a href="mailto:contact@prestonzen.com">Contact <Arrow diagonal /></a>
        </nav>
      </header>

      <section className="intro" id="top" aria-labelledby="intro-title">
        <div className="intro__copy">
          <p className="eyebrow">OSAKA, JAPAN · PORTRAIT PHOTOGRAPHER</p>
          <h1 id="intro-title">A moment,<br /><em>held gently.</em></h1>
          <p className="intro__description">Quiet, natural portraits that leave room for you to be yourself.</p>
          <a className="text-link" href="#work">Explore selected work <Arrow /></a>
        </div>
        {photos[0] && (
          <a className="intro__image" href="#work" aria-label="View selected portrait">
            <img src={photos[0].src} alt={photos[0].alt} fetchPriority="high" />
            <span className="intro__image-note">01 / SELECTED PORTRAITS</span>
          </a>
        )}
      </section>

      <section className="work section-wrap" id="work" aria-labelledby="work-title">
        <div className="section-heading">
          <div><p className="eyebrow">A FEW RECENT FRAMES</p><h2 id="work-title">Selected work</h2></div>
          {photos.length > 0 && <span className="work-count">{String(visiblePhotos.length).padStart(2, '0')} photographs</span>}
        </div>
        {photos.length > 0 ? (
          <>
            <div className="filter-row" role="group" aria-label="Filter photographs by category">
              {categories.map((item) => <button key={item} className={category === item ? 'filter is-active' : 'filter'} onClick={() => setCategory(item)} aria-pressed={category === item}>{item}</button>)}
            </div>
            <div className="gallery">
              {visiblePhotos.map((photo) => <PhotoCard key={photo.src} photo={photo} onOpen={openPhoto} />)}
            </div>
          </>
        ) : (
          <p className="gallery-note">Selected photographs will appear here.</p>
        )}
      </section>

      <section className="about section-wrap" id="about" aria-labelledby="about-title">
        <div className="about__label"><p className="eyebrow">A LITTLE ABOUT ME</p><span className="about__index">01 — 03</span></div>
        <div className="about__copy">
          <h2 id="about-title">People first.<br /><em>Pictures follow.</em></h2>
          <p>I'm Preston, a portrait photographer based in Higashiosaka. I've spent 12 years learning to notice the small things that make a portrait feel like you.</p>
          <p>I grew up learning from my photographer father, and later from mentor Dan Alka. Today I bring that care to relaxed sessions around Osaka, with a particular love for kimono portraits.</p>
          <a className="text-link" href="mailto:contact@prestonzen.com">Ask about a session <Arrow /></a>
        </div>
      </section>

      <section className="session section-wrap" aria-labelledby="session-title">
        <div><p className="eyebrow">THE SESSION</p><h2 id="session-title">Simple, personal,<br /><em>unhurried.</em></h2></div>
        <div className="session__details">
          <p>Private kimono portrait sessions in Osaka, with a small collection of kimono available to borrow.</p>
          <ul>
            <li><span>01</span> Two hours together</li>
            <li><span>02</span> One or two guests</li>
            <li><span>03</span> Ten edited digital photographs within seven days</li>
          </ul>
          <p className="session__note">Hair, makeup and specialist dressing services aren't provided.</p>
          <a className="text-link" href="mailto:contact@prestonzen.com?subject=Portrait%20session%20inquiry">Start a conversation <Arrow diagonal /></a>
        </div>
      </section>

      <footer className="site-footer">
        <a className="wordmark" href="#top">PRESTON <span>ZEN</span></a>
        <p>Portraits made with care in Osaka.</p>
        <a className="footer-email" href="mailto:contact@prestonzen.com">contact@prestonzen.com <Arrow diagonal /></a>
        <small>© {new Date().getFullYear()} Preston Zen</small>
      </footer>

      {activePhoto && <Lightbox photo={activePhoto} onClose={closeLightbox} onMove={moveLightbox} />}
    </main>
  );
}
