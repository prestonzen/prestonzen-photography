# Preston Zen Photography

Mobile-first React and Vite portfolio for Preston Zen, a portrait photographer in Osaka. The portfolio uses four reviewed kimono portraits from the approved photo set. Public derivatives are resized and contain no copied image metadata; original photographs remain untouched in Downloads.

## Local development

- Node.js 24 LTS
- `npm install`
- `npm run dev`
- `npm run build`
- `npm run preview`

Optimized, EXIF-stripped JPEG derivatives belong in `public/images/`. Add reviewed image paths, factual alt text, short titles, and evidence-based categories to `src/site/photos.js`.

## Cloudflare Pages

Create a Pages project from this repository with:

- Framework preset: **Vite**
- Build command: `npm run build`
- Build output directory: `dist`
- Node.js version: `24`

After the project is deployed, open **Workers & Pages → the project → Custom domains** and add `photography.prestonzen.com`. Follow the exact DNS instruction shown by Cloudflare for the domain; do not change unrelated records. Verify the Pages deployment and the custom-domain TLS status separately.

## Content notes

- Kimono portrait sessions are in Osaka, last two hours, and are for one or two guests.
- A limited kimono collection is available. Hair, makeup, and specialist dressing services are not included.
- Ten selected edited digital photographs are delivered within seven days.
- Contact: [contact@prestonzen.com](mailto:contact@prestonzen.com)
- About copy reflects 12 years of experience, learning from Preston's photographer father, and mentor Dan Alka. It does not imply endorsement.
- This self-authored portfolio is not independent reviews or press coverage.
